// script.js

console.log('Koyto site loaded');
